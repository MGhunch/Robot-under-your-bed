# Handover to the build side — link-pull done, facts.json is full

*21 Aug 2026, from the content side. Companion to your `facts-amendments-v3.md`. This closes the job your v3 doc called "the content side's next session": the link-pull is done, in one sitting, per the sourcing brief.*

---

## What's landing

**`facts.json` — complete and final for launch.** Drop it straight over the v1 file in `public/`.

| | v1 (what you have) | This file |
|---|---|---|
| Slugs | 22 | 22 |
| Reckons | 22 | 22 (unchanged) |
| Research entries | 0 | **63** |
| "Still checking" rows | 17 | **0** |
| "Nothing to declare" rows | 5 | 8 |
| `checked` | `2026-08` | `2026-08-21` |

Schema is your v3 exactly: `reckons` + `research`, item shape `{quote, source, link}`, all three required, no `link` in a reckon, dates as written. It should pass your validator clean — if anything trips, that's a bug on our side, shout.

**`link-pull-report.md`** — the full record: every entry with its receipt, 17 rescope notes with Michael's rulings, and the flags below. Reference, not a build input.

## Six links to click before ship

Everything else was verified at point of pull. These six are canonical addresses that need one human click before the page goes live (report has the detail):

1. `https://ssi.inc`
2. `https://www.nobelprize.org/prizes/physics/2024/`
3. `https://www.nobelprize.org/prizes/chemistry/2024/` (carries three robot-scientists entries)
4. `https://abcnews.com/Business/sam-altman-reaches-deal-return-ceo-openai/story?id=105091534` (if it bounces, same story at abcnews.go.com)
5. `https://time.com/archive/6909920/arts-great-whodunit-the-mona-lisa-theft-of-1911/`
6. `https://amp.cbc.ca/lite/story/1.1373641` (works; swap to the canonical www.cbc.ca URL if you'd rather not ship an AMP link)

If any 404s, don't improvise a replacement — flag it back and we'll re-pull.

## Rulings applied since your v3 (all Michael's, 21 Aug)

- **NFT $25B entry ships** with DappRadar's $23B report as the receipt and a source line that owns the rounding ("we rounded up with the crowd"). Ruled explicitly — do not "fix" the mismatch.
- **The two verb fixes are CONFIRMED**: "the robots **are** more similar" and "The basics… **are** sound". These were flagged at the top of our worksheet and in your v3's "Still with Michael" section — that item is now closed. The reckons in this facts.json carry the fixed text and are final.
- **"Even experts studying deepfakes"** stays as written. Logged as a *potential tweak* (below), not a change.

## Potential tweaks — a list to keep, not to act on

Michael asked for a running list of lines that survive with a note. One item so far:

1. **ai-mageddon / deepfakes** — receipt proves *people* detect at ~50%; "experts" is a stretch in the honest direction. If the book line is ever softened, "Even people studying deepfakes" is the candidate. No action now.

Add to this list as things surface; it travels with the report.

## Things the fact page inherits, restated

- One entry (`last-horse` stadium) has a source line that credits the book's own arithmetic — that's deliberate, per the worksheet flag. Same pattern on cow-shark and the Tuesday.
- Two entries share one receipt in several places (IBM Deep Blue ×2, ACS penicillin ×2, Science/He Jiankui ×2, Linda Hall/Semmelweis ×2, OpenAI-Musk blog ×2, Nobel chemistry ×3, Challenger ×2, IEEE Spectrum ×3, Fortune longform ×3, Time archive + PBS on the Louvre). One link per fact holds; reuse across facts was always allowed.
- Straight apostrophes and minimal em-dashes throughout, copied not retyped — the verbatim check should pass. The two known punctuation shapes are the curly quotes inside the Lovelace nested quote (hers) and "2001: A Space Odyssey" italics markers stripped per the corpus.

## Fixture reminder

`facts-sample.json` still must never ship. This file replaces the need for it — you now have real text lengths in every state the renderer handles.

*— content side, 21 Aug 2026*
